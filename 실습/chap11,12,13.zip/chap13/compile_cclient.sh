gcc -o cclient cclient.c readline.h readline.c

#include <stdio.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#define DEFAULT_PROTOCOL 0
#define MAXLINE 100

 /* 파일 클라이언트 프로그램 */
 int main (int argc, char* argv[])
 {
   int clientFd, port, result;
   char *host, inmsg[MAXLINE], outmsg[MAXLINE];
   struct sockaddr_in serverAddr;
   struct hostent *hp;

   if (argc != 3) {
      fprintf(stderr, "사용법 : %s <host> <port>\n", argv[0]);
      exit(0);
   }

   host = argv[1]; // 127.0.0.1, 192.168.15.128
   port = atoi(argv[2]);
   clientFd = socket(AF_INET, SOCK_STREAM, DEFAULT_PROTOCOL);


   bzero((char *) &serverAddr, sizeof(serverAddr));
   serverAddr.sin_family = AF_INET;
   
   serverAddr.sin_addr.s_addr = inet_addr(argv[1]);
   serverAddr.sin_port = htons(port);

   do { /* 연결 요청 */
      result = connect(clientFd, &serverAddr,  sizeof(serverAddr));
      if (result == -1) sleep(1);
   } while (result == -1);

   printf("파일 이름 입력:");
   scanf("%s", inmsg);
   write(clientFd,inmsg,strlen(inmsg)+1);

   /* 소켓으로부터 파일 내용 읽어서 프린트 */
   while (readLine(clientFd,outmsg))
      printf("%s", outmsg);
   close(clientFd);
   exit(0);
 }


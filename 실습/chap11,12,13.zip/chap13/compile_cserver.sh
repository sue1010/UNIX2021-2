gcc -o cserver cserver.c readline.h readline.c

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
   int status1, status2, status3, child, pid1, pid2, pid3;

   pid1 = fork();
   if ( pid1 == 0)
   {
	   fprintf(stdout,"[%d]\n",getpid());
	   execl("../ac_create", "ac_create", argv[1], NULL);
       fprintf(stderr,"failed 1");
       exit(1);
   }
   waitpid(pid1, &status1, 0);

   pid2 = fork();
   if ( pid2 == 0)
   {
	   fprintf(stdout,"[%d]\n",getpid());
       execl("../ac_update", "ac_update", argv[1], NULL);
       fprintf(stderr,"failed 2");
       exit(1);
   }
   waitpid(pid2, &status2, 0);

   pid3 = fork();
   if ( pid3 == 0)
   {
	   fprintf(stdout,"[%d]\n",getpid());
       execl("../ac_query", "ac_query", argv[1], NULL);
       fprintf(stderr,"failed 3");
       exit(1);
   }
   waitpid(pid3, &status3, 0);
}

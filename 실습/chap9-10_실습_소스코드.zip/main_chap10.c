#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "account.h"
/* Save account information */
int main(int argc, char *argv[])
{
   int ac_num, i, idx, money, cur_balance;
   struct account *record;
   printf("set the number of account: ");
   scanf("%d", &ac_num);

   record = (struct account *)malloc(ac_num * sizeof(struct account));

   printf("Index   %-9s %-8s %-4s\n", "ID", "Name", "Balance");
   for (i=0; i < ac_num; i++)
   {
	   printf("   %d   ", i+1);
	   scanf("%d %s %d", &record[i].id, record[i].name, &record[i].balance);

   }
   while (1)
   {
	   printf("Account index to access: ");
	   scanf("%d", &idx);
	   if (idx <= 0 || idx > ac_num)
	   {
		   printf("Index should be in 1 to %d\n", ac_num);
		   continue;
	   }
	   printf("Index: %2d ID:%8d\t Name:%4s\t Balance:%4d\n", idx, record[idx-1].id, record[idx-1].name, record[idx-1].balance);
	   while (1)
	   {
		   printf("Amount of money to withdraw: ");
		   scanf("%d", &money);
		   cur_balance = record[idx-1].balance - money;
		   if (cur_balance < 0)
		   {
			   printf("should be smaller than %d\n", record[idx-1].balance);
		   }
		   else
		   {
			   record[idx-1].balance = cur_balance;
			   printf("Balance: %d\n", record[idx-1].balance);
			   break;
		   }
	   }

   }
   free(record);
   exit(0);
}

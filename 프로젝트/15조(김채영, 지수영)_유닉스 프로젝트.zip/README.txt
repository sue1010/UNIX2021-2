gcc -o cserver cserver.c
gcc -o cclient cclient.c

#define LMAX 20

struct locker{
	int index;
	char password[LMAX];
	char now[LMAX];
	char memo[500];
};
